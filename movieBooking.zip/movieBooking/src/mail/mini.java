/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mail;

/**
 *
 * @author POOJA
 */
public class mini {
    public static void main(String[] args)throws Exception{
        mail.sendMail("vlekhasri159@gmail.com");
    }
    
}
